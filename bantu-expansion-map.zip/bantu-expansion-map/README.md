# The Bantu Expansion: Interactive Map

An interactive map of how Bantu languages and farming spread across central, eastern and southern Africa between about 3000 BCE and 1500 CE. It has:

- A timeline you can play or drag.
- Two route models to switch between or compare: late split and early split.
- 16 sites you can click, each tagged by the kind of evidence behind it (linguistic, archaeological, genetic, environmental).
- Layers you can turn on and off: the rainforest, the peoples already living in each region, and where Bantu languages are spoken today.

The whole map is one self-contained file, `index.html`. It needs no server code, no build step and no internet connection, except for loading web fonts.

## Hosting on GitHub Pages

1. Create a new public repository on GitHub, e.g. `bantu-expansion-map`.
2. Upload the contents of this folder so that `index.html` sits at the top level of the repository. On github.com you can drag the files onto **Add file → Upload files**.
3. In the repository, go to **Settings → Pages**.
4. Under **Build and deployment**, set **Source** to *Deploy from a branch*, then choose the branch `main` and the folder `/ (root)`. Click **Save**.
5. After a minute or two the map is live at `https://<your-username>.github.io/bantu-expansion-map/`.

You can also open `index.html` straight from your computer by double-clicking it.

## Editing the content

The `src/` folder holds the editable source. `index.html` is generated from it.

| File | What it controls |
|---|---|
| `src/sites.json` | Every clickable site: name, coordinates, the year it appears, evidence tags, description, source |
| `src/peoples.json` | Labels for the peoples already living in each region |
| `src/build.mjs` | Route lines for both models, the rainforest and language-area outlines, rivers, lakes and map labels |
| `src/template.html` | Page layout, styling, timeline phase captions and the overview text in the side panel |

Small text fixes can be made directly in `index.html`. Search for the sentence you want to change. To rebuild after editing anything in `src/`, you need [Node.js](https://nodejs.org) 18 or newer:

```bash
cd src
npm install
npm run build   # rewrites ../index.html
```

Each site in `sites.json` looks like this. The `//` comments are explanations only and can't go in the real file:

```jsonc
{
  "id": "kwale",
  "name": "Kwale",
  "place": "Kenyan coast, near Mombasa",
  "lon": 39.45, "lat": -4.17,
  "year": 150,                 // when it appears on the timeline (negative = BCE)
  "when": "c. 2nd–3rd century CE",
  "ev": ["archaeological"],    // first tag sets the marker colour
  "text": "Main description…",
  "note": "Optional highlighted note…",
  "src": "Optional source citation"
}
```

If you add a new site, also add a short map label and label position for its `id` in the `SHORT` and `LABEL_POS` lists near the top of the script in `src/template.html`.

## About the data

Route lines and dates are simplified, hand-drawn generalizations of published reconstructions, and they remain debated. The rainforest and modern language-area outlines are approximate. Country borders come from [Natural Earth](https://www.naturalearthdata.com/) via the `world-atlas` package (public domain).

Key sources:

- de Filippo et al. 2012, *Proc. R. Soc. B*, doi:10.1098/rspb.2012.0318
- Grollemund et al. 2015, *PNAS*
- Patin et al. 2017, *Science*
- Lipson et al. 2020, *Nature*, doi:10.1038/s41586-020-1929-1
- Semo et al. 2020, *Molecular Biology and Evolution*
- Seidensticker et al. 2021, *Science Advances*, doi:10.1126/sciadv.abd8352
- Koile et al. 2022, *PNAS*, doi:10.1073/pnas.2112853119
