import fs from 'fs';
import { feature } from 'topojson-client';
import { geoAzimuthalEqualArea, geoPath } from 'd3-geo';

const W = 900, H = 790;
const topo = JSON.parse(fs.readFileSync(new URL('./node_modules/world-atlas/countries-50m.json', import.meta.url)));
const countries = feature(topo, topo.objects.countries);

const proj = geoAzimuthalEqualArea().rotate([-24, 12]);
proj.fitExtent([[10, 10], [W - 10, H - 10]], {
  type: 'MultiPoint', coordinates: [[1, 10.5], [50, 10.5], [20, -35.2], [3, -20], [50.5, -26], [28, 11]]
});
const path = geoPath(proj).digits(1);
const P = ([lon, lat]) => proj([lon, lat]).map(v => Math.round(v * 10) / 10);

const AFRICA_IDS = new Set(); // keep everything visible; clip happens via viewBox
const land = [];
for (const f of countries.features) {
  const [[x0, y0], [x1, y1]] = path.bounds(f);
  if (x1 < -50 || y1 < -50 || x0 > W + 50 || y0 > H + 50) continue;
  const d = path(f);
  if (!d) continue;
  const c = path.centroid(f);
  land.push({ d, af: c[0] > 0 && c[0] < W && c[1] > 0 && c[1] < H && !['Saudi Arabia','Yemen','Oman','Spain','Italy','Greece','Turkey','Syria','Iraq','Israel','Jordan','Lebanon','Portugal','France','Cyprus','Malta','Palestine','United Arab Emirates','Iran','Kuwait','Qatar','Bahrain','Albania','Bulgaria','Macedonia','Montenegro','Bosnia and Herz.','Croatia','Serbia','Kosovo','Slovenia','Azerbaijan','Georgia','Armenia'].includes(f.properties.name) });
}

const poly = pts => 'M' + pts.map(P).map(p => p.join(',')).join('L') + 'Z';
const line = pts => 'M' + pts.map(P).map(p => p.join(',')).join('L');

// --- Reference geography (hand-approximated) ---
const rainforest = [[9.4,4.6],[10.6,5.0],[12.5,4.6],[14.5,4.2],[16.2,3.9],[18.3,4.3],[20.5,4.4],[23,4.6],[25.5,4.4],[27.8,3.6],[29.4,2.4],[30,0.8],[29.5,-1.3],[28.8,-3.2],[27.2,-4.8],[25,-5.4],[22.6,-5.6],[20.4,-4.6],[18.2,-3.9],[16.4,-3.6],[14.6,-4.3],[12.6,-4.6],[11.3,-3.7],[9.6,-2.2],[9.1,-0.4],[9.4,1.8],[9.6,3.4]];
const sri = [[15.6,4.2],[17.6,4.0],[18.0,1.5],[17.4,-1.2],[16.0,-1.0],[15.8,1.6]];
const bantuToday = [[8.7,4.7],[9.8,6.6],[11.4,6.3],[12.6,5.0],[14.6,4.6],[16.2,3.6],[18.6,3.6],[21,2.9],[24,2.6],[27,2.2],[29.2,1.6],[30.6,2.6],[32.6,2.2],[34.2,1.2],[35.2,0.2],[37.6,0.8],[39.4,-0.8],[41.2,-1.6],[40.2,-3.4],[39.4,-5.8],[39.6,-8.4],[40.4,-10.6],[40.6,-14.8],[39.4,-16.8],[36.4,-19],[35.4,-22.4],[35.4,-24.2],[32.9,-26.2],[32.4,-28.8],[30.8,-30.6],[28.4,-32.6],[26.2,-33.8],[24.6,-33.2],[24.2,-29.8],[23.2,-27.4],[21.6,-25.6],[21,-22.6],[19.8,-21],[16.6,-21.4],[14.4,-20],[13.2,-17.2],[11.8,-16.4],[12.4,-13.4],[13.2,-9.6],[12.3,-6.1],[11.9,-4.6],[10.2,-2.4],[9.3,-0.6],[9.4,1.9],[9.7,3.4]];
const lakes = {
  victoria: [[31.8,-1.0],[32.2,0.3],[33.2,0.4],[34.1,0.0],[34.6,-0.4],[34.0,-1.5],[33.3,-2.3],[32.6,-2.6],[31.8,-2.2],[31.6,-1.4]],
  tanganyika: [[29.05,-3.3],[29.4,-3.4],[29.7,-5],[30.6,-6.8],[31.2,-8.5],[30.8,-8.8],[30.2,-7.2],[29.4,-6.2],[29.1,-4.8]],
  malawi: [[34.2,-9.5],[34.6,-10.2],[34.9,-11.4],[35.3,-13.2],[34.8,-14.4],[34.4,-13.6],[34.1,-11.8],[33.9,-10.2]]
};
const rivers = {
  congo: [[25.85,-9.2],[26.4,-7.0],[27.0,-5.4],[26.6,-4.5],[25.9,-2.95],[25.4,-0.6],[25.2,0.5],[23.8,1.0],[22.5,1.8],[21.5,2.15],[19.9,1.6],[18.3,0.05],[17.2,-1.6],[16.4,-3.0],[15.3,-4.3],[13.8,-5.4],[12.3,-6.0]],
  sangha: [[15.6,4.2],[16.1,2.8],[16.6,1.0],[17.0,-0.6],[17.2,-1.6]],
  zambezi: [[24.3,-11.4],[22.6,-13.6],[23.2,-15.6],[24.6,-17.6],[25.85,-17.9],[27.5,-17.0],[28.9,-16.2],[30.4,-15.7],[33.6,-16.15],[35.3,-17.3],[36.3,-18.8]],
  limpopo: [[27.4,-24.6],[28.4,-22.8],[29.37,-22.2],[30.4,-22.3],[31.3,-22.4],[32.3,-23.6],[33.6,-25.2]],
  niger: [[-10.5,9.5],[-8,12],[-5,14.2],[-3,16.6],[-0.5,16.4],[1.5,14.5],[3.6,11.8],[5.2,9.6],[6.7,7.9],[6.6,6.0],[6.2,4.3]]
};

// --- Routes: [lon, lat, year] ---
const R = {
  late: [
    { id: 'trunk', branch: 'trunk', pts: [[10.4,6.0,-3000],[11.6,4.0,-2600],[13.8,2.6,-2400],[16.2,1.0,-2200],[18.4,-0.8,-2000],[19.8,-3.2,-1700],[21,-5.8,-1300]] },
    { id: 'nwcoast', branch: 'west', pts: [[11.6,4.0,-2600],[10.4,1.6,-2100],[10.2,-1.2,-1600],[11.8,-3.8,-1200]] },
    { id: 'west', branch: 'west', pts: [[21,-5.8,-1300],[17.6,-6.4,-1000],[15.6,-9.2,-600],[15.2,-12.6,-200],[15.8,-15.4,200],[16.2,-17.6,600]] },
    { id: 'southcentral', branch: 'west', pts: [[21,-5.8,-1300],[22.6,-9.4,-700],[24.4,-12.6,-100],[26.0,-15.2,300]] },
    { id: 'east', branch: 'east', pts: [[21,-5.8,-1300],[24.2,-6.0,-1050],[27.4,-4.6,-800],[30.4,-2.4,-600],[33.6,-0.4,-450]] },
    { id: 'eastcoast', branch: 'east', pts: [[30.4,-2.4,-600],[32.6,-3.6,-300],[36.4,-4.0,0],[39.2,-4.3,150]] },
    { id: 'south', branch: 'east', pts: [[30.4,-2.4,-600],[31.2,-6.0,-300],[32.4,-10.2,0],[33.0,-13.6,120],[31.6,-17.6,220],[32.0,-21.6,260],[32.4,-25.6,300],[30.8,-28.6,420],[28.4,-31.8,650]] },
    { id: 'inland_south', branch: 'east', pts: [[31.6,-17.6,220],[29.6,-21.4,350],[29.6,-24.8,450]] },
  ],
  early: [
    { id: 'trunk', branch: 'trunk', pts: [[10.4,6.0,-3000],[12.4,5.6,-2700]] },
    { id: 'east', branch: 'east', pts: [[12.4,5.6,-2700],[15.6,5.4,-2450],[19.2,5.0,-2150],[22.8,4.6,-1850],[26.4,3.6,-1550],[29.4,1.6,-1200],[31.2,-0.6,-900],[33.6,-0.4,-500]] },
    { id: 'eastcoast', branch: 'east', pts: [[31.2,-0.6,-900],[32.6,-3.6,-400],[36.4,-4.0,0],[39.2,-4.3,150]] },
    { id: 'south', branch: 'east', pts: [[31.2,-0.6,-900],[31.2,-6.0,-300],[32.4,-10.2,0],[33.0,-13.6,120],[31.6,-17.6,220],[32.0,-21.6,260],[32.4,-25.6,300],[30.8,-28.6,420],[28.4,-31.8,650]] },
    { id: 'inland_south', branch: 'east', pts: [[31.6,-17.6,220],[29.6,-21.4,350],[29.6,-24.8,450]] },
    { id: 'west', branch: 'west', pts: [[12.4,5.6,-2700],[11.6,3.6,-2500],[10.6,0.8,-2100],[11.6,-2.6,-1700],[14.0,-4.8,-1300],[15.6,-8.6,-800],[15.2,-12.6,-300],[15.8,-15.4,150],[16.2,-17.6,600]] },
    { id: 'westinterior', branch: 'west', pts: [[14.0,-4.8,-1300],[17.6,-2.0,-1000],[20.4,-0.4,-700]] },
    { id: 'southcentral', branch: 'west', pts: [[15.6,-8.6,-800],[19.6,-9.4,-500],[22.6,-11.4,-200],[24.4,-12.6,0],[26.0,-15.2,300]] },
  ]
};

// Densify a route with Catmull-Rom in projected space, interpolating years
function densify(pts) {
  const p = pts.map(([lo, la, y]) => { const [x, yy] = P([lo, la]); return [x, yy, y]; });
  const out = [];
  const n = p.length;
  for (let i = 0; i < n - 1; i++) {
    const p0 = p[Math.max(0, i - 1)], p1 = p[i], p2 = p[i + 1], p3 = p[Math.min(n - 1, i + 2)];
    const steps = 14;
    for (let s = 0; s < steps; s++) {
      const t = s / steps, t2 = t * t, t3 = t2 * t;
      const f = (a, b, c, d) => 0.5 * ((2 * b) + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t2 + (-a + 3 * b - 3 * c + d) * t3);
      out.push([Math.round(f(p0[0], p1[0], p2[0], p3[0]) * 10) / 10, Math.round(f(p0[1], p1[1], p2[1], p3[1]) * 10) / 10, Math.round(p1[2] + (p2[2] - p1[2]) * t)]);
    }
  }
  const last = p[n - 1];
  out.push([last[0], last[1], last[2]]);
  return out;
}
const routes = {};
for (const m of Object.keys(R)) routes[m] = R[m].map(r => ({ id: r.id, branch: r.branch, pts: densify(r.pts) }));

const sites = JSON.parse(fs.readFileSync(new URL('./sites.json', import.meta.url)));
for (const s of sites) [s.x, s.y] = P([s.lon, s.lat]);
const peoples = JSON.parse(fs.readFileSync(new URL('./peoples.json', import.meta.url)));
for (const s of peoples) [s.x, s.y] = P([s.lon, s.lat]);

const labels = [
  ['L. Victoria', 33.0, -3.1, 'lake'], ['L. Tanganyika', 28.2, -6.0, 'lake'], ['L. Malawi', 36.0, -11.6, 'lake'],
  ['Congo R.', 23.4, 2.2, 'river'], ['Zambezi R.', 28.8, -15.4, 'river'], ['Limpopo R.', 27.0, -23.6, 'river'], ['Niger R.', 5.0, 8.4, 'river'],
  ['ATLANTIC OCEAN', 4, -16, 'ocean'], ['INDIAN OCEAN', 47, -6, 'ocean'], ['equatorial rainforest', 14.6, -2.5, 'forest'], ['Kalahari', 20.4, -22.8, 'region'], ['Madagascar', 46.8, -19.5, 'region'],
].map(([t, lo, la, k]) => { const [x, y] = P([lo, la]); return { t, x, y, k }; });

const data = {
  W, H, land,
  rainforest: poly(rainforest), sri: poly(sri), bantuToday: poly(bantuToday),
  lakes: Object.values(lakes).map(poly), rivers: Object.values(rivers).map(line),
  routes, sites, peoples, labels
};
const tpl = fs.readFileSync(new URL('./template.html', import.meta.url), 'utf8');
fs.writeFileSync(new URL('../index.html', import.meta.url), tpl.replace('/*__DATA__*/null', JSON.stringify(data)));
console.log('size', fs.statSync(new URL('../index.html', import.meta.url)).size, 'land', land.length);
